import { FunctionComponent, useState } from "react";
import FrameComponent from "../components/FrameComponent";
import ServicesContent from "../components/ServicesContent";
import TrustedBy from "../components/TrustedBy";
import PlatformBenefits from "../components/PlatformBenefits";
import PlatformBenefits1 from "../components/PlatformBenefits1";
import Pricing from "../components/Pricing";
import Pricing1 from "../components/Pricing1";
import styles from "./WebsiteLandingPageDarkMod.module.css";

const WebsiteLandingPageDarkMod: FunctionComponent = () => {
  const [isDark, setDark] = useState(true);
  window.addEventListener('themeChanged', (e) => {
    if(isDark) {
      setDark(false);
    } else {
      setDark(true);
    }
  })
  return (
    <div className={styles.websiteLandingPageDarkMod}>
      <FrameComponent />
          <img
            className={styles.image17Icon}
            // loading="lazy"
            alt=""
            src={isDark ? "/image_17.svg" : '/image_20.svg'}
          />
      <div className={styles.heroGraphic}>
        <div className={styles.heroGraphicChild} />
        <div className={styles.heroImage}></div>
      </div>
      <main className={styles.services}>
        <ServicesContent />
        <TrustedBy />
        <PlatformBenefits />
        {/* <Testimonials /> */}
        <PlatformBenefits1 />
        <Pricing />
        <Pricing1 />
      </main>
    </div>
  );
};

export default WebsiteLandingPageDarkMod;

import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import BlogPage from "./pages/BlogPage";
import WebsiteLandingPageDarkMod from "./pages/WebsiteLandingPageDarkMod";
import MachineLearning from "./components/BlogsPage/MachineLearning";
import DemandForecasting from "./components/BlogsPage/DemandForecasting";
import PredictiveMaintanance from "./components/BlogsPage/PredictiveMaintenance";
import SmartManufacturing from "./components/BlogsPage/SmartMenufacturing";
import Offering from "./pages/Offering";
import AboutUs from "./pages/AboutUs";
import OfferingPage from "./pages/OfferingPage";
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.js';


function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;
  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/websitelanding-page-dark-mode":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag: HTMLMetaElement | null = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      
      <Route
        path="/blog"
        element={<BlogPage />}
      />
      <Route
        path="/services"
        element={<Offering />}
      />
      <Route
        path="/offering"
        element={<OfferingPage />}
      />
      <Route
        path="/about-us"
        element={<AboutUs />}
      />
      <Route
        path="/demand forecasting"
        element={<DemandForecasting />}
      />
      <Route
        path="/machine-learning"
        element={<MachineLearning />}
      />
      <Route
        path="/predictive-maintenance"
        element={<PredictiveMaintanance />}
      />
      <Route
        path="/smart-manufacturing"
        element={<SmartManufacturing />}
      />
      <Route path="/" element={< WebsiteLandingPageDarkMod />} />
    </Routes>
  );
}
export default App;

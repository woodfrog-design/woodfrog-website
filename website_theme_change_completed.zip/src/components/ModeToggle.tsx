import { FunctionComponent, useState } from "react";
import styles from "./ModeToggle.module.css";

export type ModeToggleType = {
  className?: string;
};

const ModeToggle: FunctionComponent<ModeToggleType> = ({ className = "" }) => {
  const [theme, setTheme] = useState(false);
  const [logo, setLogo] = useState('/vector.svg');
  const toggleTheme = ()=> {
    const event = new CustomEvent('themeChanged');
    window.dispatchEvent(event);
    const root:any = document.querySelector(':root');
    if(theme) {
      root.style.setProperty('--color-gray-200', '#1e1e1e');
      root.style.setProperty('--dark-secondary-text', '#c7c6c8');
      root.style.setProperty('--color-darkslategray-100', '#2f2f37');
      root.style.setProperty('--color-gray-400', 'rgba(18, 18, 18, 0.95)');
      root.style.setProperty('--dark-primary-text', '#f9f8fa');
      root.style.setProperty('--color-darkgray', '#abafb5');
      root.style.setProperty('--color-darkslategray-200', '#2f2d2d');
      root.style.setProperty('--toggle-icon', '45px');
      setLogo('/vector.svg');
    } else {
      
      root.style.setProperty('--color-gray-200', '#F5F5F5');
      root.style.setProperty('--dark-secondary-text', '#000000');
      root.style.setProperty('--color-darkslategray-100', '#ffffff');
      root.style.setProperty('--color-gray-400', '#ffffff');
      root.style.setProperty('--dark-primary-text', '#000000');
      root.style.setProperty('--color-darkgray', '#808080');
      root.style.setProperty('--color-darkslategray-200', '#ffffff');
      root.style.setProperty('--toggle-icon', '50px');
      setLogo('/toggle_dark.png');
    }
    setTheme(!theme);
  }
  return (
    <div className={[styles.modeToggle, className].join(" ")}>
      <div className={styles.toggleContainer} onClick={() => toggleTheme()}>
        <img
          className={styles.toggleIcon}
          loading="lazy"
          alt=""
          src={logo}
        />
      </div>
    </div>
  );
};

export default ModeToggle;

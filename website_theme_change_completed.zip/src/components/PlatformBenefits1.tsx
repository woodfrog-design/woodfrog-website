import { FunctionComponent, useState } from "react";
import Items2 from "./Items2";
import styles from "./PlatformBenefits1.module.css";

export type PlatformBenefits1Type = {
  className?: string;
  title?: string;
  padding?: string
};

const PlatformBenefits1: FunctionComponent<PlatformBenefits1Type> = ({
  className = "", title = "Latest Insights", padding = ""
}) => {
  const [isDark, setDark] = useState(true);
  window.addEventListener('themeChanged', (e) => {
    if(isDark) {
      setDark(false);
    }  else{
      setDark(true);
    }
  })
  return (
    <section className={[styles.platformBenefits, className].join(" ")} >
      <h1 className={styles.latestInsights}>{title}</h1>
      <div className={styles.slider}>
        {/* <div className={styles.items}>
          <div className={styles.item}>
            <img
              className={styles.imageIcon}
              loading="lazy"
              alt=""
              src="/image1@2x.png"
            />
          </div>
          <div className={styles.content}>
            <h3 className={styles.enablingNextGenDigital}>
              Enabling next-gen digital expericence
            </h3>
            <div className={styles.button}>
              <img
                className={styles.actionIcon}
                loading="lazy"
                alt=""
                src="/frame-5.svg"
              />
            </div>
          </div>
        </div> */}
        <Items2 image="/image@2x.png" text="Machine Learning " name="machine-learning" />
        <Items2 image="/image-1@2x.png" text="Predictive Maintenance " name="predictive-maintenance" />
        <Items2 image="/image-2@2x.png" text="Smart Manufacturing" name="smart-manufacturing" />
        <Items2 image="/image-2@2x.png" text="Demand Forecasting" name="demand forecasting" />

      </div>
      {/* <div className={styles.rectangleParent}>
        <div className={styles.frameChild} />
        <div className={styles.button1} />
      </div> */}
    </section>
  );
};

export default PlatformBenefits1;

import { FunctionComponent } from "react";
import BarChart from "./BarChart";
import ChartDotIcon from "./ChartDotIcon";
import styles from "./ServicesContent.module.css";

export type ServicesContentType = {
  className?: string;
};

const ServicesContent: FunctionComponent<ServicesContentType> = ({
  className = "",
}) => {
  return (
    <section className={[styles.servicesContent, className].join(" ")}>
      <h1 className={styles.coreServices}>Core Services</h1>
      <div className={styles.servicesGrid}>
        <div className={styles.servicesColumns}>
          <div className={styles.servicesColumn}>
            <div className={styles.serviceItems}>
              <h3 className={styles.dataEngineering}>Data Engineering</h3>
              <div className={styles.diagram}>
                <div className={styles.diagramElements}>
                  <div className={styles.diagramElementsChild} />
                  <div className={styles.diagramElementsChild} />
                  <div className={styles.diagramElementsChild} />
                </div>
                <div className={styles.diagramInner}>
                  <img
                    className={styles.frameChild}
                    alt=""
                    src="/arrow-1.svg"
                  />
                </div>
                <div className={styles.frameWrapper}>
                  <img
                    className={styles.frameIcon}
                    loading="lazy"
                    alt=""
                    src="/frame.svg"
                  />
                </div>
                <div className={styles.diagramInner}>
                  <img
                    className={styles.frameChild}
                    alt=""
                    src="/arrow-1.svg"
                  />
                </div>
                <div className={styles.frameWrapper}>
                  <img className={styles.frameIcon} alt="" src="/frame-1.svg" />
                </div>
              </div>
              <div className={styles.efficientlyManageAnd}>
                Efficiently manage and transform your data pipelines, ensuring
                data is clean, organized, and ready for advanced analytics.
              </div>
              <div className={styles.analyticsColumn}>
                <img
                  className={styles.analyticsSpacerIcon}
                  alt=""
                  src="/analytics-spacer@2x.png"
                />
                <div className={styles.barChart}>
                  <div className={styles.bar} />
                  <div className={styles.bar} />
                  <div className={styles.bar} />
                  <div className={styles.bar} />
                  <div className={styles.bar} />
                  <div className={styles.bar} />
                  <div className={styles.bar} />
                  <div className={styles.bar} />
                  <div className={styles.bar} />
                  <div className={styles.bar} />
                  <div className={styles.bar} />
                  <div className={styles.bar} />
                </div>
              </div>
            </div>
            <div className={styles.servicesDetails}>
              <h3 className={styles.analytics}> Analytics</h3>
              <BarChart
                barChartItemPropHeight="40px"
                barChartItemPropHeight1="102px"
                barChartItemPropHeight2="75px"
                barChartItemPropHeight3="54px"
                barChartItemPropHeight4="71px"
                barChartItemPropHeight5="28px"
                barChartItemPropHeight6="89px"
                barChartItemPropHeight7="63px"
                barChartItemPropHeight8="98px"
                barChartItemPropHeight9="33px"
                barChartItemPropHeight10="83px"
                barChartItemPropHeight11="75px"
                barChartItemPropHeight12="120px"
                barChartItemPropHeight13="54px"
                barChartItemPropJustifyContent="center"
                barChartItemPropJustifyContent1="flex-start"
                barChartItemPropJustifyContent2="flex-start"
                barChartItemPropJustifyContent3="center"
                barChartItemPropJustifyContent4="flex-start"
                barChartItemPropJustifyContent5="center"
                barChartItemPropJustifyContent6="flex-start"
                barChartItemPropJustifyContent7="flex-start"
                barChartItemPropJustifyContent8="flex-start"
                barChartItemPropJustifyContent9="center"
                barChartItemPropJustifyContent10="flex-start"
                barChartItemPropJustifyContent11="flex-start"
                barChartItemPropJustifyContent12="flex-start"
                barChartItemPropJustifyContent13="center"
                barChartItemPropHeight15="40px"
                barChartItemPropHeight16="102px"
                barChartItemPropHeight17="75px"
                barChartItemPropHeight18="54px"
                barChartItemPropHeight19="71px"
                barChartItemPropHeight110="28px"
                barChartItemPropHeight111="89px"
                barChartItemPropHeight112="63px"
                barChartItemPropHeight113="98px"
                barChartItemPropHeight114="33px"
                barChartItemPropHeight115="83px"
                barChartItemPropHeight116="75px"
                barChartItemPropHeight117="120px"
                barChartItemPropHeight118="54px"
              />
              <div className={styles.gainActionableInsights}>
                Gain actionable insights through data-driven analytics that
                empower smarter, faster business decisions.
              </div>
            </div>
          </div>
          <div className={styles.servicesColumn}>
            <div className={styles.llmopsLargeLanguageModelOParent}>
              <h3 className={styles.dataEngineering}>
                LLMOps (Large Language Model Operations)
              </h3>
              <div className={styles.frameDiv}>
                <div className={styles.lineChartParent}>
                  <img
                    className={styles.lineChartIcon}
                    alt=""
                    src="/line-chart.svg"
                  />
                  <ChartDotIcon />
                </div>
              </div>
              <div className={styles.efficientlyManageAnd}>
                Manage and operationalize large language models efficiently,
                ensuring seamless integration and performance across
                applications.
              </div>
            </div>
            <div className={styles.frameParent}>
              <div className={styles.machineLearningParent}>
                <h3 className={styles.machineLearning}>Machine Learning</h3>
                <div className={styles.efficientlyManageAnd}>
                  Implement machine learning models that automate tasks and
                  uncover patterns for predictive business insights.
                </div>
              </div>
              <div className={styles.machineLearningParent}>
                <h3 className={styles.dataEngineering}>MLOps</h3>
                <div className={styles.efficientlyManageAnd}>
                  Optimize machine learning model lifecycles with efficient
                  workflows, ensuring seamless deployment, monitoring, and
                  scalability.
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.model}>
          <h3 className={styles.llmLargeLanguage}>
            LLM (Large Language Models)
          </h3>
          <img
            className={styles.lineChartIcon1}
            loading="lazy"
            alt=""
            src="/line-chart-1.svg"
          />
          <div className={styles.efficientlyManageAnd}>
            Manage and operationalize large language models efficiently,
            ensuring seamless integration and performance across applications.
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServicesContent;

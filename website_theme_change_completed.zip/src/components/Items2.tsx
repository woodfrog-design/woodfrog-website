import { FunctionComponent, useState } from "react";
import styles from "./Items2.module.css";
import { useNavigate } from "react-router-dom";

export type Items2Type = {
  className?: string;
  image?: string;
  text?: string;
  name?: string
};

const Items2: FunctionComponent<Items2Type> = ({ className = "", image, text = "Enabling next-gen digital expericence", name = "" }) => {
  const navigate = useNavigate()
  const [isDark, setDark] = useState(true);
  window.addEventListener('themeChanged', (e) => {
    if(isDark) {
      setDark(false);
    }  else{
      setDark(true);
    }
  })
  return (
    <div className={[styles.items, className].join(" ")} onClick={() => navigate(`/${name}`)}>
      <img className={styles.imageIcon} loading="lazy" alt="" src={image} />
      <div className={styles.enablingNextGenDigitalExpeParent}>
        <h5 className={styles.enablingNextGenDigital}>
          {text}
        </h5>
        <div className={styles.frameWrapper} >
          <img
            className={styles.frameIcon}
            loading="lazy"
            alt=""
            src={isDark ? "/frame-5.svg" : '/frame-5-light.svg'}
          />
        </div>
      </div>
    </div>
  );
};

export default Items2;

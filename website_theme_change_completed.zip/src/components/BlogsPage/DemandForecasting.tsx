import { FunctionComponent } from "react";
import styles from "../HorizontalTabs.module.css";
import Badge from "../Badge";
import HEADER from "../HEADER";
import PlatformBenefits1 from "../PlatformBenefits1";
import "./Common.css"

export type HorizontalTabsType = {
    className?: string;
};

const DemandForecasting: FunctionComponent<HorizontalTabsType> = ({
    className = "",
}) => {
    return (
        <div className={styles.blogPage}>
            <HEADER tagline={true} />
            <div className={styles.horizontalTabsParent}>
                <div className={[styles.horizontalTabs, className].join(" ")}>
                    <div className={styles.frameParent}>
                        <div className={styles.frameGroup}>
                            <img className={styles.frameIcon} alt="" src="/frame.svg" />
                            <div className={styles.insurance}>Insurance/</div>
                        </div>
                        <div className={styles.theEvolutionAnd}>
                            Demand Forecasting Project Guide
                        </div>
                    </div>
                    <div className={styles.badgeParent}>
                        <Badge
                            propAlignSelf="unset"
                            propMixBlendMode="unset"
                            text="Artifical Intelligence"
                            propBackgroundColor="#c1f8d7"
                            propColor="#037a48"
                            textTextDecoration="unset"
                        />
                        <Badge
                            propAlignSelf="unset"
                            propMixBlendMode="normal"
                            text="Machine Learning"
                            propBackgroundColor="#f0f9ff"
                            propColor="#026aa2"
                            textTextDecoration="unset"
                        />
                        <Badge
                            propAlignSelf="unset"
                            propMixBlendMode="normal"
                            text="Deep Learning"
                            propBackgroundColor="#fffaeb"
                            propColor="#b64708"
                            textTextDecoration="unset"
                        />
                        <Badge
                            propAlignSelf="unset"
                            propMixBlendMode="normal"
                            text="Natural Language Processing"
                            propBackgroundColor="#f4f3ff"
                            propColor="#5925dc"
                            textTextDecoration="unset"
                        />
                        <Badge
                            propAlignSelf="unset"
                            propMixBlendMode="normal"
                            text="Computer Vision"
                            propBackgroundColor="#fdf2fa"
                            propColor="#c11574"
                            textTextDecoration="unset"
                        />
                        <Badge
                            propAlignSelf="unset"
                            propMixBlendMode="normal"
                            text="Cloud"
                            propBackgroundColor="#fdf2fa"
                            propColor="#c11574"
                            textTextDecoration="unset"
                        />
                    </div>
                    <div className={styles.generativeAiAContainer}>
                        <h2 className="subheader">1. Introduction</h2>
                        <p className="paragraph">
                            The demand forecasting project is a pivotal initiative aimed at enhancing inventory management and streamlining supply chain operations within the healthcare sector. In an industry where timely access to medical supplies can have profound impacts on patient care, accurate demand forecasting is essential. As healthcare providers face increasing pressures to optimize their resources, effective demand forecasting offers a strategic advantage by ensuring that the right amount of inventory is available at the right time.
                        </p>
                        <p className="paragraph">
                            The primary objective of this project is to develop a robust forecasting pipeline that predicts three-month sales for critical medical supplies. This will not only help healthcare clients manage their inventories more effectively but also reduce costs associated with overstocking and stockouts. By leveraging data-driven insights, healthcare providers can make informed decisions that enhance service delivery and operational efficiency.
                        </p>

                        <h3 className="subsubheader">1.1 Who We Are</h3>
                        <p className="paragraph">
                            At the forefront of the demand forecasting project is WoodFrog, a dedicated team of data scientists and AI specialists with a proven track record in delivering innovative solutions tailored to the healthcare sector. Our expertise lies in leveraging artificial intelligence and advanced data analysis techniques to transform complex datasets into actionable insights. With years of experience in predictive modeling, our team is uniquely positioned to tackle the challenges faced by healthcare providers in managing inventory and ensuring the timely availability of medical supplies.
                        </p>

                        <h3 className="subsubheader">1.2 What We Offer</h3>
                        <p className="paragraph">
                            The demand forecasting project at WoodFrog provides a suite of innovative solutions designed to enhance predictive analytics capabilities, automate forecasting processes, and facilitate efficient decision-making within the healthcare sector. By leveraging advanced statistical models like ARIMA and Prophet, we empower our clients to make data-driven decisions that optimize resource allocation and improve operational efficiency.
                        </p>

                        <h3 className="subsubheader">1.3 What We Need from You</h3>
                        <p className="paragraph">
                            For the successful implementation of the demand forecasting solution, it is essential that we establish a collaborative partnership with our clients. This collaboration hinges on the provision of specific data and insights that will contextualize our forecasting models and enhance their accuracy and relevance.
                        </p>

                        <h3 className="subsubheader">1.4 What You Will Gain</h3>
                        <p className="paragraph">
                            Implementing our demand forecasting solution will provide your organization with a multitude of benefits, fundamentally transforming how you manage inventory and respond to customer needs. Here are the key advantages you can expect:
                        </p>
                        <ul className="list">
                            <li>Enhanced Inventory Management</li>
                            <li>Better Alignment with Customer Demand</li>
                            <li>Reduced Waste</li>
                            <li>Improved Financial Outcomes</li>
                            <li>Strategic Decision-Making</li>
                        </ul>

                        <h3 className="subsubheader">1.5 Why Us?</h3>
                        <p className="paragraph">
                            Choosing WoodFrog for your demand forecasting needs offers a competitive edge that stems from our unique methodologies, proven track record of success, and unwavering commitment to delivering impactful results tailored to your specific requirements.
                        </p>

                        <h2 className="subheader">2. Problem Statement</h2>
                        <p className="paragraph">
                            In the healthcare sector, the ability to accurately forecast demand for medical supplies is critical for maintaining operational efficiency and ensuring patient satisfaction. However, our client faced significant challenges in this area, primarily stemming from the unpredictability of medicine demand.
                        </p>

                        <h3 className="subsubheader">2.1 Data Overview</h3>
                        <p className="paragraph">
                            In our demand forecasting project, the dataset utilized is both comprehensive and multifaceted, encompassing a rich array of data points crucial for predicting three-month sales of medical supplies.
                        </p>

                        <h3 className="subsubheader">2.2 Data Processing and Feature Engineering</h3>
                        <p className="paragraph">
                            Effective data processing and feature engineering are crucial steps in preparing our dataset for analysis and model training in the demand forecasting project.
                        </p>

                        <h3 className="subsubheader">2.3 Exploratory Data Analysis (EDA)</h3>
                        <p className="paragraph">
                            Exploratory Data Analysis (EDA) is a critical step in understanding the underlying patterns, trends, and anomalies present in the dataset, especially in the context of demand forecasting for healthcare supplies.
                        </p>

                        <h2 className="subheader">3. Model Selection</h2>
                        <p className="paragraph">
                            In the demand forecasting project, several models were considered to predict three-month sales for medical supplies, with a focus on ARIMA (AutoRegressive Integrated Moving Average) and Prophet models.
                        </p>

                        <h2 className="subsubheader">4. Model Considerations and Rationale</h2>
                        <p className="paragraph">
                            When selecting models for demand forecasting, particularly in the healthcare sector, several key criteria must be considered to ensure the chosen methods are suitable for the complexities of the data and the specific objectives of the project.
                        </p>

                        <h2 className="subsubheader">5. Model Training</h2>
                        <p className="paragraph">
                            The training process for the selected ARIMA and Prophet models involved a structured approach to ensure that the models were effectively tuned to predict three-month sales for medical supplies.
                        </p>

                        <h2 className="subsubheader">6. Simulation Setup</h2>
                        <p className="paragraph">
                            In the demand forecasting project, a rigorous simulation setup was implemented to evaluate model performance effectively.
                        </p>

                        <h3 className="subsubheader">6.1 Hyperparameter Tuning</h3>
                        <p className="paragraph">
                            Hyperparameter tuning is a critical aspect of model training that involves adjusting parameters to optimize the performance of machine learning algorithms.
                        </p>

                        <h2 className="subsubheader">7. Evaluation Metrics</h2>
                        <p className="paragraph">
                            In the realm of demand forecasting, evaluating model performance is crucial to ensure accuracy and reliability in predictions.
                        </p>

                        <h2 className="subsubheader">8. Model Evaluation and Results</h2>
                        <p className="paragraph">
                            The evaluation of the ARIMA and Prophet models revealed essential insights into their performance, strengths, and weaknesses in predicting three-month sales for medical supplies in the healthcare sector.
                        </p>

                        <h2 className="subsubheader">9. Continuous Improvement</h2>
                        <p className="paragraph">
                            Continuous improvement is essential for maintaining the effectiveness of the demand forecasting model in an ever-evolving healthcare environment.
                        </p>

                        <h2 className="subsubheader">10. Impact Analysis and Deployment</h2>
                        <p className="paragraph">
                            The deployment of the forecasting model has yielded significant improvements in inventory management and supply chain efficiency for our healthcare client.
                        </p>

                        <h2 className="subsubheader">11. The Client's Perspective</h2>
                        <p className="paragraph">
                            The client's experience with the demand forecasting project has been transformative, fundamentally reshaping their operational strategies and enhancing their overall efficiency.
                        </p>
                    </div>
                </div>
                <div className={styles.platformBenefits}>

                    <PlatformBenefits1 title="Recommended Articles" padding="0px" />
                </div>
            </div>

        </div>

    );
};

export default DemandForecasting;

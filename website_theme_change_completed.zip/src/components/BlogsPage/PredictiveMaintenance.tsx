import { FunctionComponent } from "react";
import styles from "../HorizontalTabs.module.css";
import Badge from "../Badge";
import HEADER from "../HEADER";
import PlatformBenefits1 from "../PlatformBenefits1";
import "./Common.css"

export type HorizontalTabsType = {
    className?: string;
};

const PredictiveMaintanance: FunctionComponent<HorizontalTabsType> = ({
    className = "",
}) => {
    return (
        <div className={styles.blogPage}>
            <HEADER tagline={true} />
            <div className={styles.horizontalTabsParent}>
                <div className={[styles.horizontalTabs, className].join(" ")}>
                    <div className={styles.frameParent}>
                        <div className={styles.frameGroup}>
                            <img className={styles.frameIcon} alt="" src="/frame.svg" />
                            <div className={styles.insurance}>Smart Monitoring/</div>
                        </div>
                        <div className={styles.theEvolutionAnd}>
                            Smart Monitoring: Machine Learning for Early Fault Detection
                            in Gas Turbines
                        </div>
                    </div>
                    <div className={styles.badgeParent}>
                        <Badge
                            propAlignSelf="unset"
                            propMixBlendMode="unset"
                            text="Artifical Intelligence"
                            propBackgroundColor="#c1f8d7"
                            propColor="#037a48"
                            textTextDecoration="unset"
                        />
                        <Badge
                            propAlignSelf="unset"
                            propMixBlendMode="normal"
                            text="Machine Learning"
                            propBackgroundColor="#f0f9ff"
                            propColor="#026aa2"
                            textTextDecoration="unset"
                        />
                        <Badge
                            propAlignSelf="unset"
                            propMixBlendMode="normal"
                            text="Deep Learning"
                            propBackgroundColor="#fffaeb"
                            propColor="#b64708"
                            textTextDecoration="unset"
                        />
                        <Badge
                            propAlignSelf="unset"
                            propMixBlendMode="normal"
                            text="Natural Language Processing"
                            propBackgroundColor="#f4f3ff"
                            propColor="#5925dc"
                            textTextDecoration="unset"
                        />
                        <Badge
                            propAlignSelf="unset"
                            propMixBlendMode="normal"
                            text="Computer Vision"
                            propBackgroundColor="#fdf2fa"
                            propColor="#c11574"
                            textTextDecoration="unset"
                        />
                        <Badge
                            propAlignSelf="unset"
                            propMixBlendMode="normal"
                            text="Cloud"
                            propBackgroundColor="#fdf2fa"
                            propColor="#c11574"
                            textTextDecoration="unset"
                        />
                    </div>
                    <div className={styles.generativeAiAContainer}>


                        <h2 className="subheader">1. Introduction</h2>

                        <h3 className="subsubheader">1.1 Who We Are</h3>
                        <p className="paragraph">
                            At WoodFrog, we specialize in delivering AI-driven solutions tailored for the manufacturing industry, where precision, efficiency, and reliability are critical. Our team leverages cutting-edge artificial intelligence techniques to address real-world production challenges, from predictive maintenance to quality control and workflow optimization.
                        </p>

                        <h3 className="subsubheader">1.2 What We Offer</h3>
                        <p className="paragraph">
                            Our AI solutions are designed to enhance productivity, reduce costs, and maximize operational efficiency, including:
                        </p>
                        <ul className="list">
                            <li>Predictive Maintenance: Reducing unplanned downtime by as much as 30% using real-time sensor data and historical trends.</li>
                            <li>Automated Quality Control: Improved product quality by up to 18%, reducing rework and enhancing product reliability.</li>
                            <li>Process Optimization: Energy consumption reductions of up to 15% through streamlined workflows and machine settings optimization.</li>
                        </ul>

                        <h3 className="subsubheader">1.3 What We Need from You</h3>
                        <p className="paragraph">
                            Our solutions require relevant production data, including historical and real-time sensor data, and insights from your team on key performance challenges. This ensures that our models are aligned precisely with your processes.
                        </p>

                        <h3 className="subsubheader">1.4 What You Will Gain</h3>
                        <p className="paragraph">
                            You will gain actionable intelligence tailored to your specific production environment, reducing downtime, increasing productivity, and ensuring long-term operational resilience and cost savings.
                        </p>

                        <h3 className="subsubheader">1.5 Why Us?</h3>
                        <p className="paragraph">
                            WoodFrog offers a results-driven approach with technical expertise and deep industry knowledge, integrating smoothly into your existing systems to deliver ROI through AI-powered predictive maintenance and workflow optimization.
                        </p>

                        <h2 className="subheader">2. Predictive Maintenance for Downtime Reduction in Aluminum Casting</h2>

                        <h3 className="subsubheader">2.1 Problem Statement</h3>
                        <p className="paragraph">
                            Frequent mold failures in the aluminum casting process were causing significant operational downtime and financial losses. Our goal was to develop a predictive maintenance solution leveraging machine learning and deep learning models to address these issues.
                        </p>

                        <h3 className="subsubheader">2.2 Auditing the Client Workflow Setup</h3>

                        <h4 className="subsubheader">2.2.1 Workflow Mapping</h4>
                        <p className="paragraph">
                            We mapped out the entire casting workflow, detailing each stage from raw material input to final product inspection, focusing on the machinery involved and historical maintenance records.
                        </p>

                        <h4 className="subsubheader">2.2.2 Stakeholder Discussions</h4>
                        <p className="paragraph">
                            Insights from production managers, engineers, and quality control teams helped pinpoint key operational metrics relevant to predicting mold performance and failure.
                        </p>

                        <h4 className="subsubheader">2.2.3 Data Collection Points</h4>
                        <p className="paragraph">
                            We identified critical data points such as sensor data, historical maintenance logs, and production quality inspection reports.
                        </p>

                        <h4 className="subsubheader">2.2.4 Challenges Identified</h4>
                        <p className="paragraph">
                            Challenges included a lack of continuous data logging and data inconsistencies, which were addressed during the data preprocessing and feature engineering phases.
                        </p>

                        <h3 className="subsubheader">2.3 Data Analysis</h3>

                        <h4 className="subsubheader">2.3.1 Data Overview</h4>
                        <p className="paragraph">
                            The dataset comprised nearly 1 million records of sensor readings and operational metrics from various stages of the aluminum casting process. Custom labeling was established to distinguish downtime events.
                        </p>

                        <h4 className="subsubheader">2.3.2 Data Processing and Feature Engineering</h4>
                        <p className="paragraph">
                            Downtime detection relied on engineered features such as rate-of-change deltas, speed threshold flags, and pressure threshold flags. These features transformed the dataset into a binary classification format.
                        </p>

                        <h4 className="subsubheader">2.3.3 Exploratory Data Analysis (EDA)</h4>
                        <p className="paragraph">
                            EDA revealed class imbalance and correlations between features like Pushout Position Error and downtime events, guiding model selection and validation.
                        </p>

                        <h3 className="subsubheader">2.4 Model Selection</h3>

                        <h4 className="subsubheader">2.4.1 Model Considerations and Rationale</h4>
                        <p className="paragraph">
                            We experimented with Random Forest, LSTM, and CNN-LSTM models. Random Forest provided a robust baseline, LSTM captured temporal dependencies, and the CNN-LSTM hybrid model combined spatial and temporal feature handling.
                        </p>

                        <h4 className="subsubheader">2.4.2 Model Selection Summary</h4>
                        <p className="paragraph">
                            Each model was selected based on its strengths in predictive accuracy and handling the characteristics of time-series data.
                        </p>

                        <h3 className="subsubheader">2.5 Simulation Setup</h3>

                        <h4 className="subsubheader">2.5.1 Training and Validation Strategy</h4>
                        <p className="paragraph">
                            We applied resampling techniques like SMOTE and time-based validation to balance the dataset and preserve temporal dependencies.
                        </p>

                        <h4 className="subsubheader">2.5.2 Hyperparameter Tuning</h4>
                        <p className="paragraph">
                            Hyperparameters were tuned for each model. For instance, Random Forest's number of trees and LSTM’s sequence length were optimized.
                        </p>

                        <h4 className="subsubheader">2.5.3 Evaluation Metrics</h4>
                        <p className="paragraph">
                            Metrics such as recall, precision, F1-score, and ROC-AUC were tracked to balance the trade-off between downtime recall and false positives.
                        </p>

                        <h3 className="subsubheader">2.6 Model Evaluation and Results</h3>

                        <h4 className="subsubheader">2.6.1 Model-1: Random Forest Classifier</h4>
                        <p className="paragraph">
                            Random Forest achieved an F1-score of 0.88 and ROC-AUC of 0.91, performing well but with limitations in handling temporal data.
                        </p>

                        <h4 className="subsubheader">2.6.2 Model-2: Long Short-Term Memory (LSTM) Network</h4>
                        <p className="paragraph">
                            LSTM achieved a recall of 0.92 and F1-score of 0.90, effectively handling time-series data and outperforming Random Forest.
                        </p>

                        <h4 className="subsubheader">2.6.3 Model-3: Hybrid CNN-LSTM Architecture</h4>
                        <p className="paragraph">
                            The hybrid CNN-LSTM model performed the best, with a recall of 0.94 and an F1-score of 0.92, providing robust downtime prediction.
                        </p>

                        <h3 className="subsubheader">2.7 Impact Analysis and Deployment</h3>

                        <h4 className="subsubheader">2.7.1 Real Business Outcomes</h4>
                        <p className="paragraph">
                            The client experienced a 29.8% reduction in unplanned downtime, leading to significant cost savings, optimized resource allocation, and increased machine utilization.
                        </p>

                        <h4 className="subsubheader">2.7.2 From Prediction to Real-Time Action</h4>
                        <p className="paragraph">
                            Real-time data processing and automated alerts enabled swift interventions, transforming the client’s operations from reactive to proactive maintenance.
                        </p>

                        <h3 className="subsubheader">2.8 The Client’s Perspective</h3>
                        <p className="paragraph">
                            The client viewed this solution as transformative, gaining control and predictability in their operations, and setting new standards in efficiency.
                        </p>


                    </div>
                </div>
                <div className={styles.platformBenefits}>

                    <PlatformBenefits1 title="Recommended Articles" padding="0px" />
                </div>
            </div>

        </div>

    );
};

export default PredictiveMaintanance;

import { FunctionComponent, useState } from "react";
import styles from "./Pricing.module.css";

export type PricingType = {
  className?: string;
};

const Pricing: FunctionComponent<PricingType> = ({ className = "" }) => {
  const [isDark, setDark] = useState(true);
  window.addEventListener('themeChanged', (e) => {
    console.log('themeChanged')
    if(isDark) {
      setDark(false);
    }  else{
      setDark(true);
    }
  })
  return (
    <section className={[styles.pricing, className].join(" ")}>
      <div className={styles.container}>
        <h1 className={styles.whyChoseUs}>Why Chose Us</h1>
      </div>
      <div className={styles.content}>
        <div className={styles.features}>
          <div className={styles.list}>
            <div className={styles.items}>
              <img
                className={styles.frameIcon}
                loading="lazy"
                alt=""
                src={isDark ? "/vector-2.svg" : '/choose/vector-2.svg'}
              />
            </div>
            <div className={styles.unmatchedRoiParent}>
              <h3 className={styles.comprehensiveEndToEndSolut}>
                Comprehensive End-to-End Solutions
              </h3>
              <div className={styles.ourExpertTeam}>
                Our expert team delivers integrated data engineering, analytics,
                machine learning (ML), and large language model (LLM) services.
                From data collection to insights and implementation, we cover
                every aspect of your data journey.
              </div>
            </div>
          </div>
          <div className={styles.list1}>
            <div className={styles.frame}>
              <img
                className={styles.frameIcon}
                loading="lazy"
                alt=""
                src={isDark ? "/frame-8.svg" : '/choose/frame-8.svg'}              />
            </div>
            <div className={styles.unmatchedRoiParent}>
              <h3 className={styles.unmatchedRoi}>Unmatched ROI</h3>
              <div className={styles.ourExpertTeam}>
                Enjoy competitive pricing without sacrificing quality. Our
                cost-effective solutions maximize your return on investment
                (ROI), balancing affordability with exceptional results.
              </div>
            </div>
          </div>
          <div className={styles.list2}>
            <div className={styles.frame}>
              <img
                className={styles.frameIcon}
                loading="lazy"
                alt=""                src={isDark ? "/frame-9.svg" : '/choose/frame-9.svg'}
              />
            </div>
            <div className={styles.unmatchedRoiParent}>
              <h3 className={styles.comprehensiveEndToEndSolut}>
                Expert Data Product Development
              </h3>
              <div className={styles.ourExpertTeam}>
                Transform raw data into actionable insights and measurable
                business outcomes. Our data product development expertise
                empowers you to make informed decisions, drive growth, and stay
                ahead of the competition.
              </div>
            </div>
          </div>
          <div className={styles.list1}>
            <div className={styles.frame}>
              <img
                className={styles.frameIcon}
                loading="lazy"
                alt=""
                src={isDark ? "/frame-10.svg" : '/choose/frame-10.svg'}
              />
            </div>
            <div className={styles.unmatchedRoiParent}>
              <h3 className={styles.comprehensiveEndToEndSolut}>
                Seamless Digital Transformation
              </h3>
              <div className={styles.ourExpertTeam}>
                Fully digitalize your data ecosystem with our expert guidance.
                Enhance efficiency, scalability, and decision-making while
                minimizing manual processes and reducing operational costs.
              </div>
            </div>
          </div>
          <div className={styles.list1}>
            <div className={styles.frame}>
              <img
                className={styles.frameIcon}
                loading="lazy"
                alt=""
                src={isDark ? "/frame-11.svg" : '/choose/frame-11.svg'}
              />
            </div>
            <div className={styles.unmatchedRoiParent}>
              <h3 className={styles.unmatchedRoi}>
                Timely Delivery and Support
              </h3>
              <div className={styles.ourExpertTeam}>
                Experience our commitment to on-time project completion and
                dedicated support. Our experienced professionals ensure smooth
                execution, addressing concerns and ensuring seamless
                integration.
              </div>
            </div>
          </div>
          <div className={styles.list1}>
            <div className={styles.frame}>
              <img
                className={styles.frameIcon}
                loading="lazy"
                alt=""
                src={isDark ? "/frame-12.svg" : '/choose/frame-12.svg'}
              />
            </div>
            <div className={styles.unmatchedRoiParent}>
              <h3 className={styles.unmatchedRoi}>Personalized Attention</h3>
              <div className={styles.ourExpertTeam}>
                Receive tailored solutions that address your unique business
                needs and challenges. Our collaborative approach aligns with
                your goals, delivering customized results that drive success.
              </div>
            </div>
          </div>
        </div>
        <div className={styles.buttonContainer}>
          <div className={styles.buttonWrapper}>
            <div className={styles.pOCButton}>
              <div className={styles.getAFree}>Get a Free POC</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pricing;

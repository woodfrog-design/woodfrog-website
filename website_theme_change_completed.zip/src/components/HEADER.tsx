import { FunctionComponent } from "react";
import Logo from "./Logo";
import ModeToggle1 from "./ModeToggle1";
import styles from "./HEADER.module.css";
import { useNavigate } from "react-router-dom";

export type HEADERType = {
  className?: string;
  tagline?: boolean;
};

const HEADER: FunctionComponent<HEADERType> = ({ className = "", tagline }) => {
  const navigate = useNavigate()
  const handleHome = () => {
    navigate('/')
  }
  return (
    <header className={[styles.header, className].join(" ")}>
      <div className={styles.headerContent}>
        <div className={styles.logoWrapper} onClick={handleHome}>
          <Logo tagline={tagline} />
        </div>

        <ModeToggle1 />
      </div>
    </header>
  );
};

export default HEADER;

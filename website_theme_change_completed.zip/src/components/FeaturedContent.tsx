import { FunctionComponent } from "react";
// import FeaturedCards from "./FeaturedCards";
import FeaturedCards1 from "./FeaturedCards1";
import styles from "./FeaturedContent.module.css";
import Items2 from "./Items2";

export type FeaturedContentType = {
  className?: string;
};

const FeaturedContent: FunctionComponent<FeaturedContentType> = ({
  className = "",
}) => {
  return (
    <div className={[styles.featuredContent,'container', className].join(" ")}>
      <div className="row">
        <div className="col col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-4">
          <FeaturedCards1 image=" /image-1@2x.png" text="Machine Learning " name="machine-learning" />
        </div>
        <div className="col col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-4">
          <FeaturedCards1 image="/image@2x.png" text="Predictive Maintenance " name="predictive-maintenance" />
        </div>
        <div className="col col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-4">
          <FeaturedCards1 image="/image-2@2x.png" text="Smart Manufacturing" name="smart-manufacturing" />
        </div>
        <div className="col col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-4">
          <FeaturedCards1 image="/image-2@2x.png" text="Demand Forecasting" name="demand forecasting" />
        </div>
      </div>


    </div>
  );
};

export default FeaturedContent;

import { FunctionComponent, useState } from "react";
import Logo from "./Logo";
import ModeToggle from "./ModeToggle";
import styles from "./FrameComponent.module.css";
import ContactForm from "./ContactUs";
import { useNavigate } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.css';
import { BsList } from "react-icons/bs";
import HeaderComponet from "./HeaderComponent";


export type FrameComponentType = {
  className?: string;
};

const FrameComponent: FunctionComponent<FrameComponentType> = ({
  className = "",
}) => {
  const naviagte = useNavigate()
  const [isModalVisible, setIsModalVisible] = useState(false);
  const handleClick = () => {
    setIsModalVisible(true)
  }
  const handleBlog = () => {
    naviagte("/blog")
  }

  let [show, setShow] = useState(false);

  const toggleEvent = (prestate: boolean) => {
    show = prestate;
    setShow(!show);
    console.log(prestate)
  }
  return (
    <>
      <div className={[styles.frameParent, className].join(" ")}>
        <HeaderComponet/>
        <div className={styles.hero}>
          <div className={styles.heroContent}>
            <div className={styles.unlockInsightsFasterWithScParent}>
              <h1
                className={styles.unlockInsightsFaster}
              >{`Unlock Insights Faster with Scalable Data Engineering & ML Solutions`}</h1>
              <h3 className={styles.transformComplexData}>
                Transform complex data into actionable insights with end-to-end
                analytics and machine learning solutions tailored to your business
                needs.
              </h3>
            </div>
            <div className={styles.heroButton} onClick={handleClick}>
              <div className={styles.heroButtonWrapper}>
                <div className={styles.aboutUs} >Get Started</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ContactForm isModalVisible={isModalVisible} setIsModalVisible={setIsModalVisible} />
    </>
  );
};
export default FrameComponent;

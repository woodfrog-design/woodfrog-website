import { FunctionComponent, useState } from "react";
import styles from "./Logo.module.css";

export type LogoType = {
  className?: string;
  tagline?: boolean;
};

const Logo: FunctionComponent<LogoType> = ({
  className = "",
  tagline = false,
}) => {

  const [isDark, setDark] = useState(true);
  window.addEventListener('themeChanged', (e) => {
    if(isDark) {
      setDark(false);
    }  else{
      setDark(true);
    }
    console.log('logo changes', isDark);
  })
  return (
    <div className={[styles.logo, className].join(" ")}>
      <a href="/">
      <img
        className={styles.logoSpacerIcon}
        loading="lazy"
        alt=""
        style={{height: '30px'}}
        src={isDark ? "/frame-759.svg" : '/logo_dark.png'}
      />
      </a>
      {tagline && (
        <div className={styles.insightsActionsInnovation}>
          Insights. Actions. Innovation.
        </div>
      )}
    </div>
  );
};

export default Logo;

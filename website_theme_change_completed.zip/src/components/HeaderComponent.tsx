import { FunctionComponent, useState } from "react";
import Logo from "./Logo";
import ModeToggle from "./ModeToggle";
import styles from "./HeaderComponent.module.css";
import ContactForm from "./ContactUs";
import { useNavigate } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.css';
import { BsList } from "react-icons/bs";
import AboutUs from "../pages/AboutUs";


export type FrameComponentType = {
  className?: string;
};

const HeaderComponet: FunctionComponent<FrameComponentType> = ({
  className = "",
}) => {
  const naviagte = useNavigate()
  const [isModalVisible, setIsModalVisible] = useState(false);
  const handleClick = () => {
    setIsModalVisible(true)
  }

  const handleMobileNavigation = (url: any) => {
    naviagte(url);
  }

  let [show, setShow] = useState(false);

  const toggleEvent = (prestate: boolean) => {
    show = prestate;
    setShow(!show);
    console.log(prestate)
  }
  return (
    <>
      <div className={[styles.frameParent, className].join(" ")}>
        <header className={styles.logoContainerWrapper}>
          <div className={styles.logoContainer}>
            <div className={styles.logoWrapper}>
              <BsList size="25px" color="white" className={['d-block d-sm-none'].join(' ')} style={{ margin: '10px' }} onClick={() => toggleEvent(show)} />
              <Logo tagline />
            </div>
            <nav className={styles.menu}>
              <div className={styles.ourSolutions} onClick={() => handleMobileNavigation('/blog')}>Blogs</div>
              <div className={styles.ourSolutions} onClick={() => handleMobileNavigation('/offering')}>Offering</div>
              <div className={styles.ourSolutions} onClick={() => handleMobileNavigation('/services')}>Services</div>
              <div className={styles.ourSolutions} onClick={() => handleMobileNavigation('/about-us')}>About Us</div>
            </nav>
            <ModeToggle />
          </div>
        </header>
      </div>
      {
        show ? (
          <div className={styles.overlay}>
            <div className={styles.overlayContent} >
              <div className="row m-0">
                <div className="col-1">
                  <div className={styles.close} onClick={() => toggleEvent(show)}>
                    <img src={'/close_menu.svg'} alt="" />
                  </div>
                </div>
                <div className="col-8">
                  <Logo tagline />
                </div>
                <div className="col-2 justify-content-center">
                  <div style={{ position: 'absolute', right: '20px', top: '12px' }}>
                    <ModeToggle />
                  </div>
                </div>
              </div>
              <div className="row m-0">
                <div className="col-12 p-0">
                  <ul className={styles.menus}>
                    <li onClick={() => handleMobileNavigation('/blog')}>Blogs</li>
                    <li onClick={() => handleMobileNavigation('/offering')}>Offering</li>
                    <li onClick={() => handleMobileNavigation('/services')}>Services</li>
                    <li onClick={() => handleMobileNavigation('/about-us')}>About US</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        ) : ''
      }
      <ContactForm isModalVisible={isModalVisible} setIsModalVisible={setIsModalVisible} />
    </>
  );
};
export default HeaderComponet;
